import React, { useState, useEffect } from 'react';
import axios from 'axios';

const CharacterInfo = () => {
  const [character, setCharacter] = useState(null);
  const [characterId, setCharacterId] = useState(1);

  useEffect(() => {
    axios.get(`https://rickandmortyapi.com/api/character/${characterId}`)
      .then(response => {
        setCharacter(response.data);
      })
      .catch(error => {
        console.error('Error fetching the character data:', error);
      });
  }, [characterId]);

  const handlePrevious = () => {
    if (characterId > 1) {
      setCharacterId(characterId - 1);
    }
  };

  const handleNext = () => {
    setCharacterId(characterId + 1);
  };

  const handleInputChange = (e) => {
    setCharacterId(Number(e.target.value));
  };

  if (!character) {
    return <div>Loading...</div>;
  }

  return (
    <div style={styles.container}>
      <img src={character.image} alt={character.name} style={styles.image} />
      <div style={styles.info}>
        <h1>{character.name}</h1>
        <p><strong>Status:</strong> {character.status}</p>
        <p><strong>Espécie:</strong> {character.species}</p>
        <p><strong>Gênero:</strong> {character.gender}</p>
        <p><strong>Origem:</strong> {character.origin.name}</p>
        <p><strong>Localidade:</strong> {character.location.name}</p>
        <p><strong>Criada:</strong> {new Date(character.created).toLocaleString()}</p>
      </div>
      <div style={styles.controls}>
        <input 
          type="number" 
          value={characterId} 
          onChange={handleInputChange} 
          style={styles.input}
        />
        <button onClick={handlePrevious} style={styles.button}>Anterior</button>
        <button onClick={handleNext} style={styles.button}>Próximo</button>
      </div>
      <div style={styles.episodes}>
        <h2>Episódio:</h2>
        <ul>
          {character.episode.map((ep, index) => (
            <li key={index}><a href={ep}>Episode {index + 1}</a></li>
          ))}
        </ul>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '20px',
  },
  image: {
    width: '200px',
    height: '200px',
    borderRadius: '10px',
  },
  info: {
    textAlign: 'center',
  },
  controls: {
    display: 'flex',
    alignItems: 'center',
    marginTop: '20px',
  },
  input: {
    marginRight: '10px',
    padding: '5px',
    fontSize: '16px',
  },
  button: {
    padding: '10px 20px',
    fontSize: '16px',
    margin: '0 5px',
  },
  episodes: {
    marginTop: '20px',
  },
};

export default CharacterInfo;
