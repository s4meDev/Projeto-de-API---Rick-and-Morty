import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import CharacterInfo from './components/CharacterInfo';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<CharacterInfo />} />
      </Routes>
    </Router>
  );
}

export default App;
